package com.solosatu.sibuta.enums

enum class GuestType {
    Penyedia, PP_PPK, Lainnya
}