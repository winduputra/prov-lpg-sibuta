package com.solosatu.sibuta.enums

enum class MeetingType {
    Permintaan_Pelayanan, Memenuhi_Undangan, Kepentingan_Lainnya
}