package com.solosatu.sibuta.ui.pages.main.components.bottomNavigation

data class NavigationItem(
    val icon: Int,
    val route: MainRoutes
)
