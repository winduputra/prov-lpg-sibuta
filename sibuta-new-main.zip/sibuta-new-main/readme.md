# SIBUTA MOBILE

1. Open file in Android Studio
2. Follow the instructions on the Android Studio